package br.ufal.barbershop.model;

import java.util.List;

/*
 * @author johnny
 */
public class Venda {
    private int codigo;
    private String cliente; /* criar a classe Cliente */ 
    private String data;
    private List produtos;
    private float totalVenda;
    
    public Venda(){}
    
    public Venda(int codigo, String cliente, String data){
        this.codigo = codigo;
        this.cliente = cliente;
        this.data = data;
    }
    
    public void gerarNotaFiscal(){
        System.out.println(this.codigo + " " + this.cliente + " " + this.data);
    }
    
    public int getCodigo(){
        return codigo;
    }
    
    public void setCodigo(int codigo){
        this.codigo = codigo;
    }
    
    public String getCliente(){
        return cliente;
    }
    
    public void setCliente(String cliente){
        this.cliente = cliente;
    }
    
    public String getData(){
        return data;
    }
    
    public void setData(String data){
        this.data = data;
    }
    
    public List getProdutos(){
        return produtos;
    }
    
    public void setProdutos(List produtos){
        this.produtos = produtos;
    }
            
            
}
