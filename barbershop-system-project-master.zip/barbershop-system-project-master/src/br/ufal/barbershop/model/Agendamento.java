package br.ufal.barbershop.model;

import java.util.Date;

public class Agendamento {

	private Date data;
	private float hora;
	private Cliente cliente;

	public Agendamento(Date data, float hora, Cliente cliente) {
		this.data = data;
		this.hora = hora;
		this.cliente = cliente;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public float getHora() {
		return hora;
	}

	public void setHora(float hora) {
		this.hora = hora;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

}
