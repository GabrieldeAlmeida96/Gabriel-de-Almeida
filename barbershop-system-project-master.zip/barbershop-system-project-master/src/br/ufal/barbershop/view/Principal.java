package br.ufal.barbershop.view;

import br.ufal.barbershop.model.Venda;

/**
 *
 * @author johnny
 */

/* CLASSE PARA TESTES */
public class Principal {
    
    public static void main(String[] args){
        Venda v = new Venda(1, "João", "13/02/2019");
        Venda w = new Venda(2, "Maria", "14/02/2019");
        v.gerarNotaFiscal();
        w.gerarNotaFiscal();
        
    }
    
}