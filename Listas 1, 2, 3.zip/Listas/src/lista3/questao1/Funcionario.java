package lista3.questao1;

// Quest�o 01
public class Funcionario {
	private String nome;
	private String cpf;
	private String email;
	private int registroUnico;
	private String dataNascimento;
	private String senha;

	public Funcionario(String nome, String cpf, String email, int registroUnico, String dataNascimento, String senha) {
		this.nome = nome;
		this.cpf = cpf;
		this.email = email;
		this.registroUnico = registroUnico;
		this.dataNascimento = dataNascimento;
		this.senha = senha;
	}

	public boolean realizarLogin(String email, String senha) {
		return email.equals(this.email) && senha.equals(this.senha);
	}

	public boolean realizarLogin(int registroUnico, String senha) {
		return (registroUnico == this.registroUnico) && senha.equals(this.senha);
	}

	public String getNome() {
		return nome;
	}

	public String getCpf() {
		return cpf;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getRegistroUnico() {
		return registroUnico;
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}
}
