package lista3.questao2;

// Quest�o 2
public class Gerente extends Funcionario {
	public Gerente(String nome, String cpf, String email, int registroUnico, String dataNascimento, String senha) {
		super(nome, cpf, email, registroUnico, dataNascimento, senha, "gerente");
	}
}