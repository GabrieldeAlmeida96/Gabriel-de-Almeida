package lista3.questao5;

public class TrabalhadorPecaProduzida extends Empregado {
	public double remuneracao;
	public int qtdProduzida;
	
	public TrabalhadorPecaProduzida(String nome, String cpf, String rg, double remuneracao, int qtdProduzida) {
		super(nome, cpf, rg);
		this.remuneracao = remuneracao;
		this.qtdProduzida = qtdProduzida;
	}

	@Override
	public double calcularGanho() {
		return remuneracao * qtdProduzida;
	}

}
