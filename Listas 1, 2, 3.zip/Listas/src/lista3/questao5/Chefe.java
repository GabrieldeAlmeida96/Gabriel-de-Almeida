package lista3.questao5;

public class Chefe extends Empregado {
	public double salarioMensal;

	public Chefe(String nome, String cpf, String rg, double salarioMensal) {
		super(nome, cpf, rg);
		this.salarioMensal = salarioMensal;
	}

	@Override
	public double calcularGanho() {
		return salarioMensal;
	}
}
