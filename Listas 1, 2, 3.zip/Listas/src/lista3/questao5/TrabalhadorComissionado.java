package lista3.questao5;

public class TrabalhadorComissionado extends Empregado {
	public double salario;
	public double comissao;
	public double qtdVendas;
	
	public TrabalhadorComissionado(String nome, String cpf, String rg, double salario, double comissao,
			double qtdVendas) {
		super(nome, cpf, rg);
		this.salario = salario;
		this.comissao = comissao;
		this.qtdVendas = qtdVendas;
	}

	@Override
	public double calcularGanho() {
		return salario + (comissao * qtdVendas);
	}

}
