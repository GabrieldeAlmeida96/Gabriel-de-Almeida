package lista3.questao5;

public class TrabalhadorHora extends Empregado {
	public double salarioHora;
	public int qtdHoras;

	public TrabalhadorHora(String nome, String cpf, String rg, double salarioHora, int qtdHoras) {
		super(nome, cpf, rg);
		this.salarioHora = salarioHora;
		this.qtdHoras = qtdHoras;
	}

	@Override
	public double calcularGanho() {
		return salarioHora * qtdHoras;
	}

}
