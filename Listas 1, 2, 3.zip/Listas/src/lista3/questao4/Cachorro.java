package lista3.questao4;

public class Cachorro extends Mamifero {
	private String tipo;

	public Cachorro(String descricao, String nome) {
		super(descricao, nome);
		this.tipo = "Cachorro";
	}
	
	@Override
	public void locomover() {
		System.out.println(tipo + "se movendo");
	}
	
	@Override
	public void alimentar() {
		System.out.println(tipo + "se alimentando");
	}
	
	public String getTipo() {
		return tipo;
	}
}
