package lista3.questao4;

public class Macaco extends Mamifero {
	private String tipo;

	public Macaco(String descricao, String nome) {
		super(descricao, nome);
		this.tipo = "Macaco";
	}
	
	@Override
	public void locomover() {
		System.out.println(tipo + "se movendo");
	}
	
	@Override
	public void alimentar() {
		System.out.println(tipo + "se alimentando");
	}

	public String getTipo() {
		return tipo;
	}
}
