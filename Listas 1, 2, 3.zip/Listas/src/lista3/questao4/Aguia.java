package lista3.questao4;

public class Aguia extends Ave {
	private String tipo;

	public Aguia(String descricao, String nome, String tipo) {
		super(descricao, nome);
		this.tipo = "�guia";
	}
	
	@Override
	public void locomover() {
		System.out.println(tipo + "se movendo");
	}
	
	@Override
	public void alimentar() {
		System.out.println(tipo + "se alimentando");
	}
	
	public String getTipo() {
		return tipo;
	}
}
