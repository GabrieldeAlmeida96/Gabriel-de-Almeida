package lista3.questao4;

public abstract class Mamifero extends Animal {

	public Mamifero(String descricao, String nome) {
		super(descricao, nome);
	}
	
	@Override
	public void locomover() {
		System.out.println("Mam�fero se movendo");
	}
	
	@Override
	public void alimentar() {
		System.out.println("Mam�fero se alimentando");
	}

	@Override
	public String getNome() {
		return super.getNome() + " � um mam�fero";
	}
}
