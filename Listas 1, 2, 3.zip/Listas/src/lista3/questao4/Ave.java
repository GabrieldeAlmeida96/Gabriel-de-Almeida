package lista3.questao4;

public abstract class Ave extends Animal {

	public Ave(String descricao, String nome) {
		super(descricao, nome);
	}
	
	@Override
	public void locomover() {
		System.out.println("Ave se movendo");
	}
	
	@Override
	public void alimentar() {
		System.out.println("Ave se alimentando");
	}

	@Override
	public String getNome() {
		return super.getNome() + " � uma ave";
	}
	
}
