package lista3.questao3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
	private static Scanner input = new Scanner(System.in);

	private static Operacao instanciarOperacao() {
		System.out.println("Selecione a opera��o:\n1.Adi��o\n2.Subtra��o\n3.Multiplica��o\n4.Divis�o");

		switch (input.nextInt()) {
		case 1:
			return new Adicao();
		case 2:
			return new Subtracao();
		case 3:
			return new Multiplicacao();
		case 4:
			return new Divisao();
		default:
			throw new ArithmeticException("Opera��o inv�lida!");
		}
	}

	public static void main(String[] args) {
		Operacao operacao = instanciarOperacao();

		System.out.println("Insira os valores: (0 encerra a entrada)");
		List<Float> numeros = new ArrayList<Float>();
		while (true) {
			float numero = input.nextFloat();
			if (numero == 0)
				break;
			else numeros.add(numero);
		}
		
		if (numeros.size() < 2) {
			throw new ArithmeticException("A opera��o requer ao menos dois valores!");
		} else if (numeros.size() == 2) {
			System.out.println(operacao.calcular(numeros.get(0), numeros.get(1)));
		} else {
			operacao.calcular(numeros);
		}
	}

}
