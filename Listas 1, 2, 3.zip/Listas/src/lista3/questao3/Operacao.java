package lista3.questao3;

import java.util.List;

public interface Operacao {
	public float calcular(float num1, float num2);
	public void calcular(List<Float> numeros);
}
