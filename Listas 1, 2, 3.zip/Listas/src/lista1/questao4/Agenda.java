package lista1.questao4;

import java.util.ArrayList;
import java.util.List;

import lista1.questao4.Nota;

// Quest�o 4
public class Agenda {
	private List<Nota> notas;
	private String dono;

	public Agenda(String dono) {
		this.notas = new ArrayList<Nota>();
		this.dono = dono;
	}

	public boolean adicionar(String dono, String texto) {
		if (this.dono.equals(dono)) {
			notas.add(new Nota(dono, texto));
			return true;
		}

		return false;
	}

	public boolean remover(Nota nota) {
		if (validarDono(nota)) {
			notas.remove(nota);
			return true;
		}

		return false;
	}

	public boolean atualizar(Nota nota, String texto) {
		if (validarDono(nota)) {
			nota.setTexto(texto);
			return true;
		}

		return false;
	}

	public boolean finalizar(Nota nota) {
		if (validarDono(nota)) {
			nota.setEstado(false);
			return true;
		}

		return false;
	}

	public List<Nota> listarTrue() {
		List<Nota> listaTrue = new ArrayList<Nota>();

		for (Nota nota : notas) {
			if (nota.isEstado()) {
				listaTrue.add(nota);
			}
		}

		return listaTrue;
	}

	public List<Nota> listarFalse() {
		List<Nota> listaFalse = new ArrayList<Nota>();

		for (Nota nota : notas) {
			if (!nota.isEstado()) {
				listaFalse.add(nota);
			}
		}

		return listaFalse;
	}

	private boolean validarDono(Nota nota) {
		return this.dono.equals(nota.getDono()) ? true : false;
	}

	public String getDono() {
		return dono;
	}

	public void setDono(String dono) {
		this.dono = dono;
	}

	public List<Nota> getNotas() {
		List<Nota> notasDono = new ArrayList<Nota>();

		for (Nota nota : notas) {
			if (validarDono(nota)) {
				notasDono.add(nota);
			}
		}

		return notasDono;
	}
}
