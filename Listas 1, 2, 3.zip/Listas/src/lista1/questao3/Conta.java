package lista1.questao3;

// Quest�o 3
public class Conta {
	private int numero;
	private float saldo;

	public Conta(int numero, float saldo) {
		this.numero = numero;
		this.saldo = saldo;
	}

	public boolean deposito(int numero, float valor) {
		if (validarConta(numero)) {
			this.saldo += valor;
			return true;
		}

		return false;
	}

	public boolean saque(int numero, float valor) {
		if (validarConta(numero) && validarSaque(valor)) {
			this.saldo -= valor;
			return true;
		}

		return false;
	}

	private boolean validarSaque(float valor) {
		return this.saldo >= valor ? true : false;
	}

	private boolean validarConta(int numero) {
		return this.numero == numero ? true : false;
	}
	
	public int getNumero() {
		return numero;
	}

	public float getSaldo() {
		return saldo;
	}
}