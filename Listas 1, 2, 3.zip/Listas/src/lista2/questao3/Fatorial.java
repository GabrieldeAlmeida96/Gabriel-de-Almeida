package lista2.questao3;

public interface Fatorial {
	public void calcular();
}
