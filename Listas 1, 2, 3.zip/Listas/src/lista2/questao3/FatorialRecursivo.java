package lista2.questao3;

public class FatorialRecursivo implements Fatorial {
	private int n;

	public FatorialRecursivo(int n) {
		this.n = n;
	}

	@Override
	public void calcular() {
		System.out.println(recursivo(n));
	}

	private int recursivo(int n) {
		if (n <= 1) {
			return 1;
		} else {
			return n * recursivo(n - 1);
		}
	}
}
