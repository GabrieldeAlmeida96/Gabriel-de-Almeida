package lista2.questao3;

public class Main {

	public static void main(String[] args) {
		Fatorial fatorialRecursivo =  new FatorialRecursivo(5);
		Fatorial fatorialIterativo =  new FatorialIterativo(5);
		
		fatorialRecursivo.calcular();
		fatorialIterativo.calcular();
	}

}
