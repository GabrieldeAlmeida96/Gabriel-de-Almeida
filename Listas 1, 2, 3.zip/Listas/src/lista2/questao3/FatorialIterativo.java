package lista2.questao3;

public class FatorialIterativo implements Fatorial {
	private int n;

	public FatorialIterativo(int n) {
		this.n = n;
	}

	@Override
	public void calcular() {
		System.out.println(iterativo(n));
	}

	private int iterativo(int n) {
		int result = 1;
		for (int i = 1; i <= n; i++) {
			result *= i;
		}

		return result;
	}
}
