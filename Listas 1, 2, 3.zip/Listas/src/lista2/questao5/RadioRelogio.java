package lista2.questao5;

import java.util.Date;

public class RadioRelogio implements Radio, Relogio {
	private Date horario;
	private boolean despertar;
	private Date horarioAlarme;
	private String emissora;
	private String tipoEmissora;
	private int volumeRadio;
	private int volumeRelogio;

	public RadioRelogio() {
		this.horario = null;
		this.despertar = false;
		this.horarioAlarme = null;
		this.emissora = "85.5";
		this.tipoEmissora = "FM";
		this.volumeRadio = 50;
		this.volumeRelogio = 50;
	}

	@Override
	public void setHorario(Date horario) {
		this.horario = horario;
	}

	@Override
	public Date getHorario() {
		return horario;
	}

	@Override
	public void setHorarioAlarme(Date horario) {
		this.horarioAlarme = horario;
	}

	@Override
	public Date getHorarioAlarme(Date horario) {
		return horarioAlarme;
	}

	@Override
	public void ligarAlarme() {
		this.despertar = true;
	}

	@Override
	public void desligarAlarme() {
		this.despertar = false;
	}

	@Override
	public void setVolumeRelogio(int vol) {
		this.volumeRelogio = vol;
	}

	@Override
	public int getVolumeRelogio() {
		return volumeRelogio;
	}

	@Override
	public void setEmissora(String emissora, String tipoEmi) {
		this.emissora = emissora;
		this.tipoEmissora = tipoEmi;
	}

	@Override
	public String getEmissora() {
		return emissora;
	}

	@Override
	public String getTipoEmissora() {
		return tipoEmissora;
	}

	@Override
	public void setVolumeRadio(int vol) {
		this.volumeRadio = vol;
	}

	@Override
	public int getVolumeRadio() {
		return volumeRadio;
	}

}
