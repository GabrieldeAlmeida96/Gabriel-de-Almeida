package lista2.questao5;

import java.util.Date;

public interface Relogio {
	public void setHorario(Date horario);
	public Date getHorario();
	public void setHorarioAlarme(Date horario);
	public Date getHorarioAlarme(Date horario);
	public void ligarAlarme();
	public void desligarAlarme();
	public void setVolumeRelogio(int vol);
	public int getVolumeRelogio();
}