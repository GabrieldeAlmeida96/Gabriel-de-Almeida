package lista2.questao1;

public class Main {

	public static void main(String[] args) {
		Ingresso ingresso = new Ingresso(101.10f);
		Ingresso ingressoVIP = new IngressoVIP(101.10f, 50.0f);
		
		System.out.println("Ingresso: " + ingresso.getValor());
		System.out.println("Ingresso VIP: " + ingressoVIP.getValor());
	}

}
