package lista2.questao1;

public class IngressoVIP extends Ingresso {
	private float valorAdicional;

	public IngressoVIP(float valor, float valorAdicional) {
		super(valor);
		this.valorAdicional = valorAdicional;
	}

	public float getValor() {
		return super.getValor() + valorAdicional;
	}

	public void setValor(float valor, float valorAdicional) {
		super.setValor(valor);
		this.valorAdicional = valorAdicional;
		
	}
	
	@Override
	public String toString() {
		return Float.toString(getValor());
	}
}
