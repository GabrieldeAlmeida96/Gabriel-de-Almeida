package lista2.questao2;

public class Vendedor extends Empregado {
	private float percentualComissao;
	
	public Vendedor(String nome, float salario, float percentualComissao) {
		super(nome, salario);
		this.percentualComissao = percentualComissao;
	}

	public float calcularSalario() {
		return super.getSalario() + ((super.getSalario() / 100.0f) * percentualComissao);
	}

	@Override
	public String toString() {
		return "Nome: " + super.getNome() + ", Sal�rio sem Comiss�o: " + salario + ", Sal�rio com Comiss�o:"
				+ calcularSalario() + ", Percentual de Comiss�o:" + percentualComissao;
	}
	
	
}
