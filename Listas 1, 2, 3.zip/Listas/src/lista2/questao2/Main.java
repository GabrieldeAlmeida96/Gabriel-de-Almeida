package lista2.questao2;

public class Main {

	public static void main(String[] args) {
		Gerente gerente = new Gerente("A", 2000.0f, "Bb");
		Vendedor vendedor = new Vendedor("B", 1000.0f, 5);
		
		System.out.println("Gerente: " + gerente.getSalario());
		System.out.println("Vendedor: " + vendedor.calcularSalario());
	}

}
