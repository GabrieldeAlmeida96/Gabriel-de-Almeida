package lista2.questao4;

public class Novo extends Imovel {
	private float adicionalPreco;

	public Novo(String endereco, float preco, float adicionalPreco) {
		super(endereco, preco);
		this.adicionalPreco = adicionalPreco;
	}

	public float getPreco() {
		return super.getPreco() + adicionalPreco;
	}
}
