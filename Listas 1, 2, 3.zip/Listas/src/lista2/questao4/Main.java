package lista2.questao4;

public class Main {

	public static void main(String[] args) {
		Imovel novo = new Novo("A", 50000.0f, 2000.0f);
		Imovel velho = new Velho("B", 50000.0f, 2000.0f);

		System.out.println("Novo: " + novo.getPreco());
		System.out.println("Velho: " + velho.getPreco());
	}

}
