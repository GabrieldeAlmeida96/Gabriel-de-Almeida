package lista2.questao4;

public class Velho extends Imovel {
	private float descontoPreco;

	public Velho(String endereco, float preco, float descontoPreco) {
		super(endereco, preco);
		this.descontoPreco = descontoPreco;
	}

	public float getPreco() {
		return super.getPreco() - descontoPreco;
	}
}